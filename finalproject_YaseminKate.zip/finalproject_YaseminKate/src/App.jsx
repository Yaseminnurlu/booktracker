import Page from "./components/Page/Page.jsx";

export default function App() {
  return (
    <>
      <Page/>
    </>
  )
}

